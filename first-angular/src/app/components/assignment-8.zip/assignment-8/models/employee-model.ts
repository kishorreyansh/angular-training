export interface EmployeeModel {
    id: number;
    name: string;
    sal: number;
    gender: string;
}
